.. cmake-module:: ../../Modules/CheckCXXSourceCompiles.cmake
