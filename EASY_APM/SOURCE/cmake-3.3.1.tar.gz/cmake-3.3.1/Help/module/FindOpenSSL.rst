.. cmake-module:: ../../Modules/FindOpenSSL.cmake
