CLEAN_NO_CUSTOM
---------------

Should the output of custom commands be left.

If this is true then the outputs of custom commands for this directory
will not be removed during the "make clean" stage.
