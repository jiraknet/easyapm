endforeach
----------

Ends a list of commands in a FOREACH block.

::

  endforeach(expression)

See the FOREACH command.
